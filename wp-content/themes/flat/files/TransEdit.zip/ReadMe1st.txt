2009.07.16

Before you begin following the process for installing the Microsoft C++ Redistributable package, please try launching TransEdit. If TransEdit launches properly, you may begin using it with no other changes.

Many software packages use the C++ package and it may have been installed without your knowledge. 


Peter T. Sabin

